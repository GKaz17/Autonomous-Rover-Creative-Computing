#include <Servo.h>
#include <Wire.h>
#include <VL53L0X.h>

//  SERVOS 
Servo leftServo;
Servo rightServo;

int leftStop  = 90;
int rightStop = 90;

// Change these if a servo spins the wrong direction/Polarity
int leftDirection  = 1;
int rightDirection = -1;

// Base forward speed
int leftBaseSpeed  = 18;
int rightBaseSpeed = 18;

// Steering correction amount
int correctionSpeed = 8;

//  SENSORS 
VL53L0X leftSensor;
VL53L0X middleSensor;
VL53L0X rightSensor;

const int XSHUT_LEFT   = 2;
const int XSHUT_MIDDLE = 3;
const int XSHUT_RIGHT  = 4;

//  WALL FOLLOW SETTINGS 
// Distances in millimeters
const int RIGHT_WALL_MIN = 400;   // 40 cm
const int RIGHT_WALL_MAX = 550;   // 55 cm

// Front obstacle distance
const int FRONT_OBSTACLE_DIST = 250;  // 25 cm

// Large reading = probably no wall on right
const int NO_WALL_DIST = 800;   // 80 cm

//  START DELAY 
unsigned long startTime = 0;
const unsigned long START_DELAY = 2000;
bool started = false;

//  SERIAL PRINT 
unsigned long lastPrint = 0;
const unsigned long printInterval = 200;

//  FUNCTION 
void driveServos(int leftSpeed, int rightSpeed) {
  leftServo.write(leftStop + (leftSpeed * leftDirection));
  rightServo.write(rightStop + (rightSpeed * rightDirection));
}

void setup() {
  Serial.begin(9600);

  leftServo.attach(9);
  rightServo.attach(10);

  // Stop servos at startup
  leftServo.write(leftStop);
  rightServo.write(rightStop);

  Wire.begin();

  pinMode(XSHUT_LEFT, OUTPUT);
  pinMode(XSHUT_MIDDLE, OUTPUT);
  pinMode(XSHUT_RIGHT, OUTPUT);

  // Turn off all sensors first
  digitalWrite(XSHUT_LEFT, LOW);
  digitalWrite(XSHUT_MIDDLE, LOW);
  digitalWrite(XSHUT_RIGHT, LOW);
  delay(10);

  // Start left sensor
  digitalWrite(XSHUT_LEFT, HIGH);
  delay(10);
  leftSensor.init();
  leftSensor.setAddress(0x30);
  leftSensor.startContinuous();

  // Start middle sensor
  digitalWrite(XSHUT_MIDDLE, HIGH);
  delay(10);
  middleSensor.init();
  middleSensor.setAddress(0x31);
  middleSensor.startContinuous();

  // Start right sensor
  digitalWrite(XSHUT_RIGHT, HIGH);
  delay(10);
  rightSensor.init();
  rightSensor.setAddress(0x32);
  rightSensor.startContinuous();

  startTime = millis();
}

void loop() {
  unsigned long currentTime = millis();

  // Wait before starting movement
  if (!started) {
    if (currentTime - startTime >= START_DELAY) {
      started = true;
      Serial.println("Starting wall follow...");
    } else {
      return;
    }
  }

  // Read all sensors
  uint16_t leftDist   = leftSensor.readRangeContinuousMillimeters();
  uint16_t middleDist = middleSensor.readRangeContinuousMillimeters();
  uint16_t rightDist  = rightSensor.readRangeContinuousMillimeters();

  // Print readings/Debug Console
  if (currentTime - lastPrint >= printInterval) {
    lastPrint = currentTime;
    Serial.print("L: ");
    Serial.print(leftDist);
    Serial.print("  M: ");
    Serial.print(middleDist);
    Serial.print("  R: ");
    Serial.println(rightDist);
  }

  // Default movement = straight forward
  int leftSpeed  = leftBaseSpeed;
  int rightSpeed = rightBaseSpeed;

  //  FRONT OBSTACLE 
  if (middleDist < FRONT_OBSTACLE_DIST) {
    // Turn left to avoid obstacle ahead
    leftSpeed  = 8;
    rightSpeed = 18;
  }

  //  RIGHT WALL FOLLOW 
  else {
    // Too close to wall then turn left
    if (rightDist < RIGHT_WALL_MIN) {
      leftSpeed  = leftBaseSpeed - correctionSpeed;
      rightSpeed = rightBaseSpeed + correctionSpeed;
    }

    // Too far from wall then turn right
    else if (rightDist > RIGHT_WALL_MAX && rightDist < NO_WALL_DIST) {
      leftSpeed  = leftBaseSpeed + correctionSpeed;
      rightSpeed = rightBaseSpeed - correctionSpeed;
    }

    // No wall detected then gently search right
    else if (rightDist >= NO_WALL_DIST) {
      leftSpeed  = leftBaseSpeed + 6;
      rightSpeed = rightBaseSpeed - 6;
    }

    // Good distance then go straight
    else {
      leftSpeed  = leftBaseSpeed;
      rightSpeed = rightBaseSpeed;
    }
  }

  // Drive rover
  driveServos(leftSpeed, rightSpeed);
}

/*
Sensor Reference Documentation

VL53L0X Time-of-Flight Distance Sensor
STMicroelectronics

Example and documentation consulted from:

Robotics.org.za – VL53L0X Continuous Ranging Example
https://www.robotics.org.za/2490?search=vl53l0x

Original library developed for Arduino using the
Pololu VL53L0X library implementation.

This sensor uses laser time-of-flight technology to measure
distance in millimetres via I2C communication.

Code adapted and integrated for obstacle detection behaviour
in a differential drive rover system.

Additional Acknowledgement:

Assistance was provided by ChatGPT (OpenAI) in understanding
the implementation and behaviour of the VL53L0X sensors,
particularly in configuring multiple sensors using XSHUT pins,
interpreting distance readings, and refining environment-aware
navigation logic.

All movement logic, system behaviour, and control strategy were
developed and implemented by the authors.
*/